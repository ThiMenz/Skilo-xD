import pyautogui
import pyscreeze
import keyboard
import math
import os
from time import sleep








#==================================
#      -- HOTKEY SETTINGS --
#==================================
START_HOTKEY = 'num0'
SPLIT_HOTKEY = 'num0'
RESET_HOTKEY = 'num1'

AUTOSPLITTER_START_HOTKEY = 't'
AUTOSPLITTER_RESET_HOTKEY = 'z'
#==================================
#==================================









































InputStringArray = ["One of the top orange pixels of the points-variable: ","Somewhere at the background of the menu: ","The green flag: ","The specific spot at the left top of the skill pass symbol: ","Exactly the middle of the skill pass symbol: ","The fullscreen-button in the fullscreen-mode: ","The file-button: ","The load from computer-button: ", "The fullscreen-button in the window-mode: ", "A specific black position of the shop icon in the menu: "]

scr = [None]*10
for i in range(1,11):
    temp = input(str(i) + ". " + InputStringArray[i-1])
    if temp == "!":
        savings = open("Savings.txt","r")
        i2 = 0
        for l in savings.readlines():
            scr[i2] = pyautogui.position(int(l.split(",")[0]),int(l.split(",")[1]))
            i2+=1
        savings.close()
        break;
    scr[i-1] = pyautogui.position()

Wsavings = open("Savings.txt","w")
i3 = 0
for p in scr: 
    Wsavings.write(str(scr[i3].x) + "," + str(scr[i3].y) + "\n")
    i3 += 1
Wsavings.close()

print(scr)

lastrgbValue = (0,0,0)

while not keyboard.is_pressed(AUTOSPLITTER_START_HOTKEY): sleep(0.05)
pyautogui.click(scr[2]) 

print("[START]")

#===================================
pyautogui.press(START_HOTKEY)
#===================================

sleep(0.5)

screen=pyscreeze.screenshot()
lastrgbValue0 = screen.getpixel(scr[0])
lastrgbValue1 = screen.getpixel(scr[1])
lastrgbValue3 = screen.getpixel(scr[3])
lastrgbValue4 = screen.getpixel(scr[4])
lastrgbValue9 = screen.getpixel(scr[9])

lastMenuTicks = 0
newLvlTicks = 0

level10Split = False

sleep(1)

while True:

    sleep(0.04)
    
    if keyboard.is_pressed(AUTOSPLITTER_RESET_HOTKEY):
        print("[RESET]")
        
        #===================================
        pyautogui.press(RESET_HOTKEY)
        #===================================
        pyautogui.click(scr[5])
        sleep(0.2)
        pyautogui.click(scr[6])
        sleep(0.2)
        pyautogui.click(scr[7])
        sleep(0.1)
        pyautogui.write(os.path.abspath("Skills_1.9.sb3"))
        sleep(0.1)
        pyautogui.press("enter")
        sleep(0.1)
        conditionPixel = pyscreeze.screenshot().getpixel(scr[8])
        sleep(0.3)
        while pyscreeze.screenshot().getpixel(scr[8]) == conditionPixel: sleep(0.1)  
        pyautogui.click(scr[8]) 
        
        level10Split = False
        while not keyboard.is_pressed(AUTOSPLITTER_START_HOTKEY): sleep(0.05)
        pyautogui.click(scr[2]) 

        print("[START]")

        #===================================
        pyautogui.press(START_HOTKEY)
        #===================================
        
        sleep(1.5)
    
    screen=pyscreeze.screenshot()
    temp_rgbValue0=screen.getpixel(scr[0])
    temp_rgbValue1=screen.getpixel(scr[1])
    
    if temp_rgbValue0 == lastrgbValue0 and temp_rgbValue1 == lastrgbValue1: lastMenuTicks += 1
    else: lastMenuTicks = 0
    
    if lastMenuTicks > 1:
    
        if screen.getpixel(scr[9]) != lastrgbValue9: continue
    
        if lastrgbValue3 == screen.getpixel(scr[3]) and lastrgbValue4 == screen.getpixel(scr[4]): 
            newLvlTicks = 0
            continue
        
        print("[CHANGED SYMBOL]")
        
        if lastrgbValue3 == screen.getpixel(scr[3]) and level10Split: continue
        elif lastrgbValue3 == screen.getpixel(scr[3]):
            if newLvlTicks > 1: level10Split = True
        
        print("[LEVEL TICK DELAY]")
        
        newLvlTicks += 1
        
        if newLvlTicks < 2: continue
        
        lastrgbValue3 = screen.getpixel(scr[3])
        lastrgbValue4 = screen.getpixel(scr[4])
        
        print("[SPLIT]")
        
        #===================================
        pyautogui.press(SPLIT_HOTKEY)
        #===================================
        
    newLvlTicks = 0
    